//Checking console.log before using below code

import app from './app.js';
import mongoose from('mongoose');

const port = 3000

//Database connection
//1-Database in another continent
//2-Database might not connect

//IFEE, immediatly invoke function
(async ()=>{
  try{
    //db connection
    await mongoose.connect('dbstring')
    console.log("DB connected Succesfully")
    
    //Catching Express error  app not work 
    app.on("error",(err)=>{
      console.error("ERROR:", err)
      throw err;
    })
    const onListining  = () =>{
      console.log(`Listining on port ${port}`)
    }
    app.listen(port, ()=>{

    })

  }catch(error){
    console.error("ERROR:", err)
    throw err;
  }

})()

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})