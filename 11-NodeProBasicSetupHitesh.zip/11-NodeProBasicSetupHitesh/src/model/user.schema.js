import mongoose from 'mongoose'

//Creating Schema for Database and write validation
const userSchema = new mongoose.Schema(
    { 
        name: {
            type: String,
            required: [true,'Name is required'],
            maxLength: [50,'Name should less than 50 Charchters']

        }, 
        email: {
            type: String,
            unique: true
        },
        username:{
            type:String,
            unique:true
        },
        password: String,
        age: Number, 
    }
    );

//Storing name in DB
export default mongoose.model("user",userSchema)